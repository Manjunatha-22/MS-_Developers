/* ==========================================================================
   GALLERY PAGE SCRIPT (gallery.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const filterBtns = document.querySelectorAll('.gallery-filter-btn');
  const items = document.querySelectorAll('.gallery-item-col');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.getAttribute('data-filter');

      items.forEach(item => {
        if (filter === 'all' || item.getAttribute('data-category') === filter) {
          item.style.display = 'block';
        } else {
          item.style.display = 'none';
        }
      });
    });
  });
});

function openLightbox(src, title) {
  const modalEl = document.getElementById('lightboxModal');
  const modalImg = document.getElementById('lightboxImg');
  const modalTitle = document.getElementById('lightboxTitle');

  if (modalEl && modalImg) {
    modalImg.src = src;
    if (modalTitle) modalTitle.innerText = title;

    if (window.bootstrap) {
      const modal = new bootstrap.Modal(modalEl);
      modal.show();
    }
  }
}
