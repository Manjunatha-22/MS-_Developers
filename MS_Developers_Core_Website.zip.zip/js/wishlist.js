/* ==========================================================================
   WISHLIST PAGE SCRIPT (wishlist.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  renderWishlistPage();
});

function renderWishlistPage() {
  const container = document.getElementById('wishlist-grid-container');
  if (!container) return;

  const wishlistIds = JSON.parse(localStorage.getItem('ms_wishlist') || '[]');
  const allProperties = JSON.parse(localStorage.getItem('ms_properties') || '[]');

  const wishProperties = allProperties.filter(p => wishlistIds.includes(p.id));

  if (wishProperties.length === 0) {
    container.innerHTML = `
      <div class="col-12 text-center py-5">
        <i class="far fa-heart text-muted display-1 mb-3"></i>
        <h3>Your Wishlist is Empty</h3>
        <p class="text-muted mb-4">Explore our luxury homes and click the heart icon to save your favorite properties.</p>
        <a href="properties.html" class="btn btn-emerald">Browse Properties</a>
      </div>
    `;
    return;
  }

  let html = '';
  wishProperties.forEach(prop => {
    html += `
      <div class="col-md-6 col-lg-4 mb-4">
        <div class="ms-card h-100">
          <div class="property-card-img-wrapper">
            <img src="${prop.image}" alt="${prop.title}">
            <span class="property-badge">${prop.badge || prop.category}</span>
            <div class="property-actions-overlay">
              <button class="btn-overlay-action active" title="Remove Wishlist" onclick="toggleWishlist('${prop.id}')">
                <i class="fas fa-heart text-danger"></i>
              </button>
            </div>
          </div>
          <div class="p-3">
            <div class="property-price-tag mb-1">${prop.priceDisplay}</div>
            <h5 class="card-title mb-1"><a href="property-details.html?id=${prop.id}">${prop.title}</a></h5>
            <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt text-secondary me-1"></i> ${prop.location}</p>
            <div class="property-features">
              <span><i class="fas fa-bed"></i> ${prop.bhk}</span>
              <span><i class="fas fa-bath"></i> ${prop.bathrooms} Baths</span>
              <span><i class="fas fa-ruler-combined"></i> ${prop.sqft} sqft</span>
            </div>
            <div class="d-flex gap-2 mt-3">
              <a href="property-details.html?id=${prop.id}" class="btn btn-outline-emerald btn-sm flex-grow-1">View Details</a>
              <button class="btn btn-gold btn-sm" onclick="openSiteVisitModal('${prop.title}')">Book Visit</button>
            </div>
          </div>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}
