/* ==========================================================================
   SATVA DEVELOPERS - CORE APPLICATION SCRIPT (app.js)
   Handles Data Store, Navbar, Dark Mode, Wishlist, Compare, Modals, Toast
   ========================================================================== */

// 1. Initial Mock Property Dataset
const DEFAULT_PROPERTIES = [
  {
    id: "prop-101",
    title: "Satva Emerald Horizons",
    category: "Apartments",
    type: "Buy",
    price: 18500000, // ₹1.85 Cr
    priceDisplay: "₹1.85 Cr",
    location: "Nagarbhavi, Bengaluru",
    bhk: "3 BHK",
    bathrooms: 3,
    sqft: 2150,
    status: "Ready to Move",
    badge: "Featured",
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=800&q=80",
    description: "Ultra luxury 3 BHK apartment featuring Italian marble flooring, sky lounge access, private balcony views of Nagarbhavi green zone, and smart home automation.",
    amenities: ["Swimming Pool", "Gymnasium", "24x7 Security", "Clubhouse", "EV Charging", "Children's Play Area"],
    possession: "Immediate",
    builder: "Satva Developers"
  },
  {
    id: "prop-102",
    title: "Satva Royal Palms Villa",
    category: "Villas",
    type: "Buy",
    price: 42000000, // ₹4.20 Cr
    priceDisplay: "₹4.20 Cr",
    location: "Indiranagar, Bengaluru",
    bhk: "4 BHK",
    bathrooms: 4,
    sqft: 4100,
    status: "Under Construction",
    badge: "Luxury Villa",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80",
    description: "Exclusive triplex luxury villa with private plunge pool, rooftop garden, imported woodwork, and 3-car private parking bay.",
    amenities: ["Private Pool", "Rooftop Garden", "Private Elevator", "Solar Power", "Smart Security"],
    possession: "Dec 2026",
    builder: "Satva Developers"
  },
  {
    id: "prop-103",
    title: "Satva Grand Plaza Commercial",
    category: "Commercial",
    type: "Buy",
    price: 35000000, // ₹3.50 Cr
    priceDisplay: "₹3.50 Cr",
    location: "Indiranagar, Bengaluru",
    bhk: "Office Space",
    bathrooms: 2,
    sqft: 3200,
    status: "Ready to Move",
    badge: "Commercial Hub",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=800&q=80",
    description: "Grade-A tech park office space with high-speed glass elevators, 100% power backup, and prime arterial road frontage.",
    amenities: ["100% Power Backup", "High Speed Elevators", "Cafeteria", "Valet Parking"],
    possession: "Immediate",
    builder: "Satva Developers"
  },
  {
    id: "prop-104",
    title: "Satva Green Acres Plot",
    category: "Plots",
    type: "Buy",
    price: 9500000, // ₹95 Lakhs
    priceDisplay: "₹95 Lakhs",
    location: "Yelahanka, Bengaluru",
    bhk: "Plot Area",
    bathrooms: 0,
    sqft: 2400,
    status: "Ready for Registration",
    badge: "Gated Plot",
    image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=800&q=80",
    description: "BDA approved premium villa plot inside gated community with underground drainage, wide bitumen roads, and avenue trees.",
    amenities: ["Gated Community", "Blacktop Roads", "Water Connection", "Underground Cabling"],
    possession: "Immediate",
    builder: "Satva Developers"
  },
  {
    id: "prop-105",
    title: "Satva Skyview Towers",
    category: "Apartments",
    type: "Rent",
    price: 65000, // ₹65,000 / mo
    priceDisplay: "₹65,000 / mo",
    location: "Whitefield, Bengaluru",
    bhk: "2 BHK",
    bathrooms: 2,
    sqft: 1450,
    status: "Ready to Move",
    badge: "Rental Special",
    image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=800&q=80",
    description: "Fully furnished modern 2 BHK apartment in Whitefield tech corridor with modular kitchen, ACs, and panoramic city views.",
    amenities: ["Furnished", "Gym", "Clubhouse", "Metro Connectivity"],
    possession: "Immediate",
    builder: "Satva Developers"
  },
  {
    id: "prop-106",
    title: "Satva Serene Meadows",
    category: "Villas",
    type: "Buy",
    price: 28000000, // ₹2.80 Cr
    priceDisplay: "₹2.80 Cr",
    location: "Yelahanka, Bengaluru",
    bhk: "3 BHK Villa",
    bathrooms: 3,
    sqft: 2900,
    status: "Upcoming",
    badge: "Pre-Launch Offer",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80",
    description: "Eco-friendly modern duplex villa surrounded by serene lakes and organic farming patches. Pre-launch inaugural price active.",
    amenities: ["Solar Water", "Organic Garden", "Clubhouse", "Badminton Court"],
    possession: "June 2027",
    builder: "Satva Developers"
  }
];

// Initialize LocalStorage Data
function initStore() {
  if (!localStorage.getItem('ms_properties')) {
    localStorage.setItem('ms_properties', JSON.stringify(DEFAULT_PROPERTIES));
  }
  if (!localStorage.getItem('ms_wishlist')) {
    localStorage.setItem('ms_wishlist', JSON.stringify([]));
  }
  if (!localStorage.getItem('ms_compare')) {
    localStorage.setItem('ms_compare', JSON.stringify([]));
  }
  if (!localStorage.getItem('ms_site_visits')) {
    localStorage.setItem('ms_site_visits', JSON.stringify([]));
  }
}

// Global Application Initialization
document.addEventListener('DOMContentLoaded', () => {
  initStore();
  setupPreloader();
  setupNavbar();
  setupThemeToggle();
  updateHeaderBadges();
  setupScrollTop();
  setupGlobalModals();
});

// Preloader
function setupPreloader() {
  const preloader = document.getElementById('preloader');
  if (preloader) {
    window.addEventListener('load', () => {
      setTimeout(() => {
        preloader.classList.add('hidden');
      }, 300);
    });
    // Fallback hide
    setTimeout(() => {
      preloader.classList.add('hidden');
    }, 1500);
  }
}

// Sticky Navbar & Active States
function setupNavbar() {
  const navbar = document.querySelector('.custom-navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 40) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
  }
}

// Dark Mode Toggle
function setupThemeToggle() {
  const toggleBtn = document.getElementById('theme-toggle-btn');
  const currentTheme = localStorage.getItem('ms_theme') || 'light';
  document.documentElement.setAttribute('data-theme', currentTheme);
  updateThemeIcon(currentTheme);

  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const theme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', theme);
      localStorage.setItem('ms_theme', theme);
      updateThemeIcon(theme);
      showToast(`Switched to ${theme.toUpperCase()} mode`, 'info');
    });
  }
}

function updateThemeIcon(theme) {
  const toggleBtn = document.getElementById('theme-toggle-btn');
  if (toggleBtn) {
    toggleBtn.innerHTML = theme === 'dark' ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
  }
}

// Wishlist Management
function toggleWishlist(propId) {
  let wishlist = JSON.parse(localStorage.getItem('ms_wishlist') || '[]');
  const index = wishlist.indexOf(propId);
  
  if (index > -1) {
    wishlist.splice(index, 1);
    showToast("Removed from Wishlist", "warning");
  } else {
    wishlist.push(propId);
    showToast("Added to Wishlist!", "success");
  }
  
  localStorage.setItem('ms_wishlist', JSON.stringify(wishlist));
  updateHeaderBadges();
  
  // Re-render if on wishlist page
  if (typeof renderWishlistPage === 'function') {
    renderWishlistPage();
  }
}

// Compare Management
function toggleCompare(propId) {
  let compare = JSON.parse(localStorage.getItem('ms_compare') || '[]');
  const index = compare.indexOf(propId);
  
  if (index > -1) {
    compare.splice(index, 1);
    showToast("Removed from Comparison list", "warning");
  } else {
    if (compare.length >= 4) {
      showToast("You can compare up to 4 properties at once.", "warning");
      return;
    }
    compare.push(propId);
    showToast("Added to Property Comparison!", "success");
  }
  
  localStorage.setItem('ms_compare', JSON.stringify(compare));
  updateHeaderBadges();
  
  // Re-render if on compare page
  if (typeof renderComparePage === 'function') {
    renderComparePage();
  }
}

// Header Badges Update
function updateHeaderBadges() {
  const wishlist = JSON.parse(localStorage.getItem('ms_wishlist') || '[]');
  const compare = JSON.parse(localStorage.getItem('ms_compare') || '[]');
  
  const wishBadge = document.getElementById('wishlist-count-badge');
  const compBadge = document.getElementById('compare-count-badge');
  
  if (wishBadge) wishBadge.innerText = wishlist.length;
  if (compBadge) compBadge.innerText = compare.length;
}

// Toast Notification System
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container-custom';
    document.body.appendChild(container);
  }
  
  const toast = document.createElement('div');
  toast.className = 'custom-toast';
  
  let icon = 'fa-info-circle';
  if (type === 'success') icon = 'fa-check-circle text-success';
  if (type === 'warning') icon = 'fa-exclamation-triangle text-warning';
  if (type === 'danger') icon = 'fa-times-circle text-danger';

  toast.innerHTML = `
    <i class="fas ${icon} fa-lg"></i>
    <div style="flex:1;">${message}</div>
    <button onclick="this.parentElement.remove()" style="background:none;border:none;color:var(--text-muted);cursor:pointer;"><i class="fas fa-times"></i></button>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 4000);
}

// Scroll to top
function setupScrollTop() {
  const btn = document.getElementById('btn-scroll-top');
  if (btn) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 300) {
        btn.classList.add('show');
      } else {
        btn.classList.remove('show');
      }
    });

    btn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
}

// Global Site Visit & Callback Modals Listener
function setupGlobalModals() {
  const siteVisitForm = document.getElementById('siteVisitForm');
  if (siteVisitForm) {
    siteVisitForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('visitName').value;
      const date = document.getElementById('visitDate').value;
      
      let visits = JSON.parse(localStorage.getItem('ms_site_visits') || '[]');
      visits.push({ name, date, timestamp: new Date().toLocaleString() });
      localStorage.setItem('ms_site_visits', JSON.stringify(visits));

      showToast(`Site Visit booked successfully for ${date}! Our relationship manager will contact you.`, 'success');
      siteVisitForm.reset();
      
      const modalEl = document.getElementById('siteVisitModal');
      if (modalEl && window.bootstrap) {
        const modal = bootstrap.Modal.getInstance(modalEl);
        if (modal) modal.hide();
      }
    });
  }

  const callbackForm = document.getElementById('callbackForm');
  if (callbackForm) {
    callbackForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const phone = document.getElementById('callbackPhone').value;
      showToast(`Callback request received for ${phone}. Expect a call within 15 minutes!`, 'success');
      callbackForm.reset();

      const modalEl = document.getElementById('callbackModal');
      if (modalEl && window.bootstrap) {
        const modal = bootstrap.Modal.getInstance(modalEl);
        if (modal) modal.hide();
      }
    });
  }
}
