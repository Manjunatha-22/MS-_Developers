/* ==========================================================================
   EMI CALCULATOR SCRIPT (emi.js)
   Formula: EMI = P * r * (1+r)^n / ((1+r)^n - 1)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const loanInput = document.getElementById('emiLoanAmount');
  const interestInput = document.getElementById('emiInterestRate');
  const tenureInput = document.getElementById('emiTenure');

  if (loanInput && interestInput && tenureInput) {
    const updateCalc = () => {
      const P = parseFloat(loanInput.value);
      const annualRate = parseFloat(interestInput.value);
      const r = (annualRate / 12) / 100;
      const n = parseFloat(tenureInput.value) * 12;

      // Labels update
      document.getElementById('emiLoanVal').innerText = '₹ ' + P.toLocaleString('en-IN');
      document.getElementById('emiInterestVal').innerText = annualRate + ' %';
      document.getElementById('emiTenureVal').innerText = tenureInput.value + ' Years';

      const emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      const totalPayment = emi * n;
      const totalInterest = totalPayment - P;

      document.getElementById('resMonthlyEmi').innerText = '₹ ' + Math.round(emi).toLocaleString('en-IN');
      document.getElementById('resTotalInterest').innerText = '₹ ' + Math.round(totalInterest).toLocaleString('en-IN');
      document.getElementById('resTotalPayment').innerText = '₹ ' + Math.round(totalPayment).toLocaleString('en-IN');
    };

    loanInput.addEventListener('input', updateCalc);
    interestInput.addEventListener('input', updateCalc);
    tenureInput.addEventListener('input', updateCalc);

    updateCalc();
  }
});
