/* ==========================================================================
   USER DASHBOARD SCRIPT (dashboard.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const loggedUser = JSON.parse(localStorage.getItem('ms_logged_user') || 'null');
  if (!loggedUser) {
    showToast("Please login to access user dashboard.", "warning");
    setTimeout(() => { window.location.href = "login.html"; }, 1500);
    return;
  }

  // Display user info
  const nameEl = document.getElementById('dashUserName');
  const emailEl = document.getElementById('dashUserEmail');
  if (nameEl) nameEl.innerText = loggedUser.name;
  if (emailEl) emailEl.innerText = loggedUser.email;

  renderDashboardVisits();
});

function renderDashboardVisits() {
  const visitsList = document.getElementById('dashSiteVisitsList');
  if (!visitsList) return;

  const visits = JSON.parse(localStorage.getItem('ms_site_visits') || '[]');

  if (visits.length === 0) {
    visitsList.innerHTML = `<p class="text-muted">No site visits booked yet.</p>`;
    return;
  }

  let html = `<ul class="list-group">`;
  visits.forEach((v, index) => {
    html += `
      <li class="list-group-item d-flex justify-content-between align-items-center">
        <div>
          <h6 class="mb-0">Site Visit - ${v.name}</h6>
          <small class="text-muted">Scheduled Date: ${v.date} | Booked on: ${v.timestamp}</small>
        </div>
        <span class="badge bg-success">Confirmed</span>
      </li>
    `;
  });
  html += `</ul>`;
  visitsList.innerHTML = html;
}

function userLogout() {
  localStorage.removeItem('ms_logged_user');
  showToast("Logged out successfully.", "info");
  setTimeout(() => { window.location.href = "login.html"; }, 1000);
}
