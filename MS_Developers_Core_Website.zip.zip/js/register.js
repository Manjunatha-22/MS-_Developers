/* ==========================================================================
   REGISTER PAGE SCRIPT (register.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('regName').value;
      const email = document.getElementById('regEmail').value;
      const phone = document.getElementById('regPhone').value;
      const pass = document.getElementById('regPassword').value;
      const confirmPass = document.getElementById('regConfirmPassword').value;

      if (pass !== confirmPass) {
        showToast("Passwords do not match!", "danger");
        return;
      }

      // Show OTP Simulation Modal
      const otpModalEl = document.getElementById('otpModal');
      if (otpModalEl && window.bootstrap) {
        const otpModal = new bootstrap.Modal(otpModalEl);
        otpModal.show();
        showToast(`OTP sent to +91 ${phone}. Use 1234 to verify.`, 'info');
      }
    });
  }

  const otpForm = document.getElementById('otpForm');
  if (otpForm) {
    otpForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const otp = document.getElementById('otpInput').value;
      if (otp === "1234" || otp.length === 4) {
        const user = { 
          name: document.getElementById('regName').value, 
          email: document.getElementById('regEmail').value,
          phone: document.getElementById('regPhone').value,
          role: "user" 
        };
        localStorage.setItem('ms_logged_user', JSON.stringify(user));
        showToast("Mobile verified & Account created successfully!", "success");
        setTimeout(() => { window.location.href = "dashboard.html"; }, 1000);
      } else {
        showToast("Invalid OTP code. Please enter 1234", "danger");
      }
    });
  }
});
