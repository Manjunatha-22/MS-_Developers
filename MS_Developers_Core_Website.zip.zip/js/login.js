/* ==========================================================================
   LOGIN PAGE SCRIPT (login.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = document.getElementById('loginEmail').value;
      const pass = document.getElementById('loginPassword').value;

      if (!email || !pass) {
        showToast("Please enter both email and password.", "danger");
        return;
      }

      // Check if Admin
      if (email === "admin@satvadevelopers.in" && pass === "admin123") {
        localStorage.setItem('ms_logged_user', JSON.stringify({ name: "System Admin", email, role: "admin" }));
        showToast("Logged in as Admin successfully!", "success");
        setTimeout(() => { window.location.href = "admin.html"; }, 1000);
        return;
      }

      // User Login Mock
      const user = { name: email.split('@')[0], email, role: "user" };
      localStorage.setItem('ms_logged_user', JSON.stringify(user));
      showToast("Logged in successfully!", "success");
      setTimeout(() => { window.location.href = "dashboard.html"; }, 1000);
    });
  }
});
