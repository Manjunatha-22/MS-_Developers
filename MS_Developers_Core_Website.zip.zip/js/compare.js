/* ==========================================================================
   COMPARE PAGE SCRIPT (compare.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  renderComparePage();
});

function renderComparePage() {
  const container = document.getElementById('compare-matrix-container');
  if (!container) return;

  const compareIds = JSON.parse(localStorage.getItem('ms_compare') || '[]');
  const allProperties = JSON.parse(localStorage.getItem('ms_properties') || '[]');

  const items = allProperties.filter(p => compareIds.includes(p.id));

  if (items.length === 0) {
    container.innerHTML = `
      <div class="text-center py-5">
        <i class="fas fa-balance-scale text-muted display-1 mb-3"></i>
        <h3>No Properties Selected for Comparison</h3>
        <p class="text-muted mb-4">Add properties to comparison list from the property cards.</p>
        <a href="properties.html" class="btn btn-emerald">Explore Properties</a>
      </div>
    `;
    return;
  }

  let html = `
    <div class="table-responsive">
      <table class="table table-bordered align-middle text-center bg-white">
        <thead class="table-light">
          <tr>
            <th style="width: 220px;" class="text-start">Feature</th>
            ${items.map(p => `
              <th>
                <div class="position-relative">
                  <button class="btn btn-sm btn-danger position-absolute top-0 end-0 m-1" onclick="toggleCompare('${p.id}')">
                    <i class="fas fa-times"></i>
                  </button>
                  <img src="${p.image}" class="img-fluid rounded mb-2" style="height:120px; object-fit:cover; width:100%;">
                  <h6>${p.title}</h6>
                  <div class="text-secondary fw-bold">${p.priceDisplay}</div>
                </div>
              </th>
            `).join('')}
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="fw-bold text-start">Category</td>
            ${items.map(p => `<td>${p.category}</td>`).join('')}
          </tr>
          <tr>
            <td class="fw-bold text-start">Location</td>
            ${items.map(p => `<td>${p.location}</td>`).join('')}
          </tr>
          <tr>
            <td class="fw-bold text-start">BHK / Type</td>
            ${items.map(p => `<td>${p.bhk}</td>`).join('')}
          </tr>
          <tr>
            <td class="fw-bold text-start">Area (sqft)</td>
            ${items.map(p => `<td>${p.sqft} sqft</td>`).join('')}
          </tr>
          <tr>
            <td class="fw-bold text-start">Bathrooms</td>
            ${items.map(p => `<td>${p.bathrooms}</td>`).join('')}
          </tr>
          <tr>
            <td class="fw-bold text-start">Possession</td>
            ${items.map(p => `<td>${p.possession}</td>`).join('')}
          </tr>
          <tr>
            <td class="fw-bold text-start">Action</td>
            ${items.map(p => `
              <td>
                <a href="property-details.html?id=${p.id}" class="btn btn-emerald btn-sm mb-1 w-100">Details</a>
              </td>
            `).join('')}
          </tr>
        </tbody>
      </table>
    </div>
  `;

  container.innerHTML = html;
}
