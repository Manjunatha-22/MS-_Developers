/* ==========================================================================
   ADMIN PANEL SCRIPT (admin.js)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  renderAdminTable();
  setupAddPropertyForm();
});

function renderAdminTable() {
  const tableBody = document.getElementById('adminPropertyTableBody');
  if (!tableBody) return;

  const props = JSON.parse(localStorage.getItem('ms_properties') || '[]');

  let html = '';
  props.forEach(p => {
    html += `
      <tr>
        <td><img src="${p.image}" style="width:50px; height:40px; object-fit:cover; border-radius:4px;"></td>
        <td class="fw-bold">${p.title}</td>
        <td>${p.category}</td>
        <td class="text-secondary fw-bold">${p.priceDisplay}</td>
        <td>${p.location}</td>
        <td>
          <button class="btn btn-sm btn-outline-danger" onclick="deleteAdminProperty('${p.id}')">
            <i class="fas fa-trash"></i>
          </button>
        </td>
      </tr>
    `;
  });

  tableBody.innerHTML = html;
}

function setupAddPropertyForm() {
  const form = document.getElementById('adminAddPropertyForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const title = document.getElementById('admPropTitle').value;
      const category = document.getElementById('admPropCategory').value;
      const price = parseFloat(document.getElementById('admPropPrice').value);
      const location = document.getElementById('admPropLocation').value;
      const bhk = document.getElementById('admPropBhk').value;
      const sqft = parseInt(document.getElementById('admPropSqft').value);
      const img = document.getElementById('admPropImg').value || "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80";

      const newProp = {
        id: "prop-" + Date.now(),
        title,
        category,
        type: "Buy",
        price,
        priceDisplay: "₹ " + price.toLocaleString('en-IN'),
        location,
        bhk,
        bathrooms: 3,
        sqft,
        status: "Ready to Move",
        badge: "New Launch",
        image: img,
        description: "Newly added luxury property by Satva Developers.",
        amenities: ["Security", "Clubhouse", "Parking"],
        possession: "Immediate",
        builder: "Satva Developers"
      };

      let props = JSON.parse(localStorage.getItem('ms_properties') || '[]');
      props.unshift(newProp);
      localStorage.setItem('ms_properties', JSON.stringify(props));

      showToast("New property added successfully!", "success");
      renderAdminTable();
      form.reset();

      const modalEl = document.getElementById('addPropertyModal');
      if (modalEl && window.bootstrap) {
        const modal = bootstrap.Modal.getInstance(modalEl);
        if (modal) modal.hide();
      }
    });
  }
}

function deleteAdminProperty(id) {
  if (confirm("Are you sure you want to delete this property listing?")) {
    let props = JSON.parse(localStorage.getItem('ms_properties') || '[]');
    props = props.filter(p => p.id !== id);
    localStorage.setItem('ms_properties', JSON.stringify(props));
    showToast("Property deleted successfully", "warning");
    renderAdminTable();
  }
}
